declare module '#content/server' {
  const serverQueryContent: typeof import('/Users/patrickbruckner/Coding/projects/klugekoepfeybbs/website/node_modules/.pnpm/@nuxt+content@2.7.0/node_modules/@nuxt/content/dist/runtime/server').serverQueryContent
  const parseContent: typeof import('/Users/patrickbruckner/Coding/projects/klugekoepfeybbs/website/node_modules/.pnpm/@nuxt+content@2.7.0/node_modules/@nuxt/content/dist/runtime/server').parseContent
}