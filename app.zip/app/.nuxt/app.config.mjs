
import { defuFn } from '/Users/patrickbruckner/Coding/projects/klugekoepfeybbs/website/node_modules/.pnpm/defu@6.1.2/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}

import cfg0 from "/Users/patrickbruckner/Coding/projects/klugekoepfeybbs/website/app/app.config.ts"
import cfg1 from "/Users/patrickbruckner/Coding/projects/klugekoepfeybbs/website/app.config.ts"

export default /* #__PURE__ */ defuFn(cfg0, cfg1, inlineConfig)
